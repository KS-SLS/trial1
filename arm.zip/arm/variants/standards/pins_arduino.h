#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#define PIN_LED 13
#define PIN_BUTTON 2
// Add more pin definitions as needed

#endif
